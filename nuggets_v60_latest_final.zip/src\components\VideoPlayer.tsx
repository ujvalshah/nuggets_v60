import React from 'react';
import { ExternalLink, Youtube } from 'lucide-react';

interface VideoPlayerProps {
  src: string;
  poster?: string;
  className?: string;
}

export const VideoPlayer: React.FC<VideoPlayerProps> = ({ src, poster, className = '' }) => {
  // Helper to extract YouTube ID
  const getYoutubeId = (url: string) => {
    const regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|&v=)([^#&?]*).*/;
    const match = url.match(regExp);
    return (match && match[2].length === 11) ? match[2] : null;
  };

  const youtubeId = getYoutubeId(src);

  if (youtubeId) {
    return (
      <div className={`flex flex-col gap-2 ${className}`}>
        <div className="relative w-full rounded-xl overflow-hidden bg-black aspect-video shadow-sm border border-slate-100 dark:border-slate-800">
          <iframe
            className="w-full h-full"
            src={`https://www.youtube-nocookie.com/embed/${youtubeId}?rel=0&origin=${window.location.origin}`}
            title="YouTube video player"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowFullScreen
          ></iframe>
        </div>
        <a
          href={src}
          target="_blank"
          rel="noopener noreferrer"
          onClick={(e) => e.stopPropagation()}
          className="flex items-center gap-1.5 text-xs font-bold text-red-600 dark:text-red-400 hover:text-red-700 dark:hover:text-red-300 transition-colors w-fit px-2 py-1 rounded-lg hover:bg-red-50 dark:hover:bg-red-900/20"
        >
          <Youtube size={16} />
          <span>Watch on YouTube</span>
          <ExternalLink size={12} className="ml-0.5" />
        </a>
      </div>
    );
  }

  // Fallback for standard video files (mp4, etc.)
  return (
    <div className={`relative w-full rounded-xl overflow-hidden bg-black aspect-video group/video shadow-sm border border-slate-100 dark:border-slate-800 ${className}`}>
      <video
        controls
        className="w-full h-full"
        poster={poster}
        src={src}
        preload="metadata"
        onClick={(e) => e.stopPropagation()}
      >
        Your browser does not support the video tag.
      </video>
    </div>
  );
};



