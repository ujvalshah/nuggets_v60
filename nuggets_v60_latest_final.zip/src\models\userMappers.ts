import { User } from '../types/user';
import { createDefaultUser } from './userDefaults';

// Assume backend payload is flat or snake_cased
interface BackendUserPayload {
  _id: string;
  email: string;
  role?: string;
  display_name?: string;
  username?: string;
  avatar_url?: string;
  preferences?: any;
  created_at?: string;
  // ... other fields
}

export const mapBackendUserToUser = (payload: BackendUserPayload): User => {
  // We use the factory to ensure no fields are missing, 
  // layering the backend data on top.
  return createDefaultUser(payload._id, payload.email, {
    role: (payload.role === 'admin' ? 'admin' : 'user'),
    auth: {
      createdAt: payload.created_at,
    },
    profile: {
      displayName: payload.display_name,
      username: payload.username,
      avatarUrl: payload.avatar_url,
    },
    preferences: payload.preferences, // Assume structure matches or add sub-mapper here
  });
};

export const mapUserToUpdatePayload = (user: User): Partial<BackendUserPayload> => {
  // Flattens the modular object back for API consumption
  return {
    email: user.auth.email,
    display_name: user.profile.displayName,
    username: user.profile.username,
    preferences: user.preferences,
  };
};




