// This component has been deprecated in favor of the unified `components/NewsCard.tsx`
// to ensure design consistency across Home Feed and Profile.
import { NewsCard } from '../NewsCard';
export const NuggetCard = NewsCard;
