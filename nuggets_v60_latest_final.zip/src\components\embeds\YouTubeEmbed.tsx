import React from 'react';
import { getYoutubeId } from '@/utils/urlUtils';
import { Play } from 'lucide-react';

interface YouTubeEmbedProps {
  url: string;
  title?: string;
  thumbnailUrl?: string;
}

export const YouTubeEmbed: React.FC<YouTubeEmbedProps> = ({ url, title, thumbnailUrl }) => {
  const videoId = getYoutubeId(url);

  if (!videoId) {
      return (
        <div className="w-full h-full flex items-center justify-center bg-slate-900 text-slate-400 text-xs">
            Invalid YouTube URL
        </div>
      );
  }

  // Use provided thumbnail or fallback to YouTube high-res default
  const poster = thumbnailUrl || `https://img.youtube.com/vi/${videoId}/maxresdefault.jpg`;

  const handleClick = (e: React.MouseEvent) => {
    e.stopPropagation(); // Prevent card expansion
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  return (
    <div 
      className="relative w-full h-full bg-slate-900 group cursor-pointer overflow-hidden"
      onClick={handleClick}
    >
      {/* Thumbnail */}
      <img 
        src={poster} 
        alt={title || "Video thumbnail"} 
        className="w-full h-full object-cover opacity-90 transition-opacity duration-300 group-hover:opacity-100"
        loading="lazy"
        onError={(e) => {
          // Fallback to hqdefault if maxres doesn't exist
          const target = e.target as HTMLImageElement;
          if (target.src.includes('maxresdefault')) {
             target.src = `https://img.youtube.com/vi/${videoId}/hqdefault.jpg`;
          }
        }}
      />

      {/* Play Overlay (WhatsApp Style) */}
      <div className="absolute inset-0 flex items-center justify-center bg-black/20 group-hover:bg-black/10 transition-colors">
        <div className="w-12 h-12 bg-slate-900/60 backdrop-blur-sm rounded-full flex items-center justify-center text-white border border-white/20 shadow-lg transform transition-transform duration-300 group-hover:scale-110">
           <Play size={20} fill="currentColor" className="ml-0.5" />
        </div>
      </div>

      {/* Metadata Overlay (Bottom) */}
      <div className="absolute bottom-0 left-0 right-0 p-3 bg-gradient-to-t from-black/80 via-black/40 to-transparent">
        <div className="flex items-center gap-1.5 text-white/90">
             <img src="https://www.youtube.com/favicon.ico" className="w-4 h-4" alt="YT" />
             <span className="text-xs font-medium truncate">{title || 'Watch on YouTube'}</span>
        </div>
      </div>
    </div>
  );
};
