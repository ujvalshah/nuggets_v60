import { createDefaultUser } from '@/models/userDefaults';
import { User } from '@/types/user';

export const MOCK_USER_ID = 'u_123456';

export const mockUser: User = createDefaultUser(MOCK_USER_ID, 'akash@nuggets.app', {
  role: 'admin',
  profile: {
    displayName: 'Akash Solanki',
    username: 'akash_ux',
    bio: 'Building minimalist interfaces. Architect @ Nuggets.',
    avatarColor: 'indigo',
    location: 'San Francisco, CA',
    website: 'https://akash.design',
  },
  preferences: {
    interestedCategories: ['Tech', 'Design', 'Psychology'],
    compactMode: false,
    theme: 'light',
  },
  appState: {
    onboardingCompleted: true,
    lastLoginAt: new Date().toISOString(),
  }
});




