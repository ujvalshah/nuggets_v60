import { getAdapter } from './adapterFactory';

export const storageService = getAdapter();




