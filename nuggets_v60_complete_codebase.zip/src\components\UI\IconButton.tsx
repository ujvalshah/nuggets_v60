import React, { ButtonHTMLAttributes, forwardRef } from 'react';
import { Tooltip } from './Tooltip';

interface IconButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  icon: React.ReactNode;
  tooltip?: string;
  variant?: 'ghost' | 'primary' | 'danger' | 'surface' | 'success';
  size?: 'sm' | 'md' | 'lg';
  className?: string;
}

export const IconButton = forwardRef<HTMLButtonElement, IconButtonProps>(({ 
  icon, 
  tooltip, 
  variant = 'ghost', 
  size = 'md', 
  className = '',
  ...props 
}, ref) => {

  const variants = {
    ghost: 'text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800',
    primary: 'text-primary-600 bg-primary-50 hover:bg-primary-100 dark:text-primary-400 dark:bg-primary-900/20 dark:hover:bg-primary-900/40',
    danger: 'text-red-500 hover:text-red-700 bg-red-50 hover:bg-red-100 dark:bg-red-900/10 dark:hover:bg-red-900/30',
    surface: 'bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:border-slate-300 shadow-sm',
    success: 'text-green-600 bg-green-50 hover:bg-green-100 dark:text-green-400 dark:bg-green-900/20 dark:hover:bg-green-900/40'
  };

  const sizes = {
    sm: 'p-1.5',
    md: 'p-2',
    lg: 'p-3'
  };

  const buttonElement = (
    <button
      ref={ref}
      className={`
        rounded-lg transition-all duration-200 flex items-center justify-center
        ${variants[variant]}
        ${sizes[size]}
        ${className}
      `}
      {...props}
    >
      {icon}
    </button>
  );

  if (tooltip) {
    return (
      <Tooltip content={tooltip}>
        {buttonElement}
      </Tooltip>
    );
  }

  return buttonElement;
});

IconButton.displayName = 'IconButton';




