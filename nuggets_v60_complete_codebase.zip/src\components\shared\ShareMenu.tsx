import React from 'react';
import { Share2 } from 'lucide-react';
import { useShare } from '@/hooks/useShare';
import { ShareModal } from '../ShareModal';
import { Tooltip } from '../UI/Tooltip';

interface ShareItemData {
  type: 'nugget' | 'collection';
  id: string;
  title: string;
  shareUrl: string;
}

interface ShareMeta {
  text?: string;   // Excerpt or Description
  author?: string;
}

interface ShareMenuProps {
  data: ShareItemData;
  meta?: ShareMeta;
  className?: string;
  iconSize?: number;
}

export const ShareMenu: React.FC<ShareMenuProps> = ({ 
  data, 
  meta, 
  className = '',
  iconSize = 14 
}) => {
  const { isOpen, anchorRect, handleShareClick, handleClose } = useShare();

  return (
    <>
      <Tooltip content="Share">
        <button 
          onClick={handleShareClick} 
          className={`w-7 h-7 flex items-center justify-center rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-400 transition-colors ${className}`}
          title="Share"
        >
          <Share2 size={iconSize} strokeWidth={1.5} />
        </button>
      </Tooltip>

      <ShareModal 
        isOpen={isOpen} 
        onClose={handleClose} 
        title={data.title} 
        url={data.shareUrl} 
        author={meta?.author} 
        excerpt={meta?.text} 
        anchorRect={anchorRect} 
      />
    </>
  );
};




