
import { Router } from 'express';
import * as tagsController from '../controllers/tagsController';

const router = Router();

router.get('/', tagsController.getTags);
router.post('/', tagsController.createTag);
router.delete('/:name', tagsController.deleteTag);

export default router;
