import { MediaType } from '@/types';

export const isValidUrl = (urlString: string): boolean => {
  try {
    const url = new URL(urlString);
    return url.protocol === "http:" || url.protocol === "https:";
  } catch (e) {
    return false;
  }
};

export const detectProviderFromUrl = (url: string): MediaType => {
  if (!isValidUrl(url)) return 'link';
  
  try {
    const hostname = new URL(url).hostname.toLowerCase();
    
    if (hostname.includes('youtube.com') || hostname.includes('youtu.be')) return 'youtube';
    if (hostname.includes('twitter.com') || hostname.includes('x.com')) return 'twitter';
    if (hostname.includes('linkedin.com')) return 'linkedin';
    if (hostname.includes('instagram.com')) return 'instagram';
    if (hostname.includes('tiktok.com')) return 'tiktok';
    
    // Simple image extension check
    if (/\.(jpeg|jpg|gif|png|webp|bmp|svg)$/i.test(url)) return 'image';

    return 'link';
  } catch (e) {
    return 'link';
  }
};

export const getProviderFromUrl = detectProviderFromUrl; // Alias for backward compatibility

export const getYoutubeId = (url: string): string | null => {
  if (!isValidUrl(url)) return null;
  try {
    // Handle both youtube.com/watch?v= and youtu.be/
    const regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|&v=)([^#&?]*).*/;
    const match = url.match(regExp);
    return (match && match[2].length === 11) ? match[2] : null;
  } catch (e) {
    return null;
  }
};

export const getTweetId = (url: string): string | null => {
  if (!isValidUrl(url)) return null;
  try {
    const match = url.match(/(?:twitter|x)\.com\/\w+\/status\/(\d+)/);
    return match ? match[1] : null;
  } catch (e) {
    return null;
  }
};


