import React from 'react';

interface TagChipProps {
  label: string;
  onClick?: () => void;
  active?: boolean;
}

export const TagChip: React.FC<TagChipProps> = ({ label, onClick, active }) => {
  return (
    <button
      onClick={(e) => {
        e.stopPropagation();
        onClick?.();
      }}
      className={`
        inline-flex items-center px-2.5 py-0.5 rounded text-xs font-medium transition-colors duration-200 border
        ${active 
          ? 'bg-primary-100 border-primary-200 text-primary-900 dark:bg-primary-900/50 dark:border-primary-800 dark:text-primary-100' 
          : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100 hover:border-slate-300 dark:bg-slate-800 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-700'
        }
      `}
    >
      #{label}
    </button>
  );
};




