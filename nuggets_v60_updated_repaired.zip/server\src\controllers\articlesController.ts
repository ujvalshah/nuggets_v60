
import { Request, Response } from 'express';

// In a real MERN app, you would import your Mongoose Model here.
// import ArticleModel from '../models/Article';

// MOCK DATA STORAGE (InMemory for demonstration purposes, mimicking DB)
// This effectively moves the LocalAdapter logic to the backend.
let ARTICLES_DB: any[] = [
  {
    id: '1',
    title: "SaaS is more than just a buzzword",
    excerpt: "Discover how software as a service is reshaping the global economy.",
    content: "Software as a Service (SaaS) has fundamentally shifted how companies operate...",
    author: { id: "u1", name: "Akash Solanki" },
    publishedAt: "2025-11-25T18:12:00",
    categories: ["Finance", "Business"],
    tags: ["Business", "SaaS"],
    readTime: 5,
    visibility: 'public',
    source_type: 'link'
  }
];

export const getArticles = async (req: Request, res: Response) => {
  try {
    const { authorId } = req.query;
    let results = ARTICLES_DB;

    if (authorId) {
      results = results.filter(a => a.author.id === authorId);
    }

    res.json(results);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching articles' });
  }
};

export const getArticleById = async (req: Request, res: Response) => {
  try {
    const article = ARTICLES_DB.find(a => a.id === req.params.id);
    if (!article) {
      return res.status(404).json({ message: 'Article not found' });
    }
    res.json(article);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching article' });
  }
};

export const createArticle = async (req: Request, res: Response) => {
  try {
    const newArticle = {
      ...req.body,
      id: Date.now().toString(),
      publishedAt: new Date().toISOString()
    };
    ARTICLES_DB.unshift(newArticle);
    res.status(201).json(newArticle);
  } catch (error) {
    res.status(500).json({ message: 'Error creating article' });
  }
};

export const updateArticle = async (req: Request, res: Response) => {
  try {
    const index = ARTICLES_DB.findIndex(a => a.id === req.params.id);
    if (index === -1) {
      return res.status(404).json({ message: 'Article not found' });
    }
    
    ARTICLES_DB[index] = { ...ARTICLES_DB[index], ...req.body };
    res.json(ARTICLES_DB[index]);
  } catch (error) {
    res.status(500).json({ message: 'Error updating article' });
  }
};

export const deleteArticle = async (req: Request, res: Response) => {
  try {
    const initialLength = ARTICLES_DB.length;
    ARTICLES_DB = ARTICLES_DB.filter(a => a.id !== req.params.id);
    
    if (ARTICLES_DB.length === initialLength) {
      return res.status(404).json({ message: 'Article not found' });
    }
    
    res.status(204).send();
  } catch (error) {
    res.status(500).json({ message: 'Error deleting article' });
  }
};
