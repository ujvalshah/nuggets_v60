import React, { useState, useCallback } from 'react';

export const useShare = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [anchorRect, setAnchorRect] = useState<DOMRect | null>(null);

  const handleShareClick = useCallback((event: React.MouseEvent) => {
    event.preventDefault();
    event.stopPropagation();
    setAnchorRect(event.currentTarget.getBoundingClientRect());
    setIsOpen(true);
  }, []);

  const handleClose = useCallback(() => {
    setIsOpen(false);
    setAnchorRect(null);
  }, []);

  return {
    isOpen,
    anchorRect,
    handleShareClick,
    handleClose
  };
};




