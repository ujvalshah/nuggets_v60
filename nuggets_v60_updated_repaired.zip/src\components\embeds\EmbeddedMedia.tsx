import React from 'react';
import { NuggetMedia } from '@/types';
import { detectProviderFromUrl } from '@/utils/urlUtils';
import { GenericLinkPreview } from './GenericLinkPreview';
import { YouTubeEmbed } from './YouTubeEmbed';
import { Image } from '../Image';

interface EmbeddedMediaProps {
  media: NuggetMedia;
  onClick?: (e: React.MouseEvent) => void;
}

export const EmbeddedMedia: React.FC<EmbeddedMediaProps> = ({ media, onClick }) => {
  const { url, type, previewMetadata } = media;

  const containerClass = "w-full h-full relative overflow-hidden bg-slate-100 dark:bg-slate-900 rounded-xl";

  // 1. Direct Image
  if (type === 'image') {
      return (
        <div className={containerClass} onClick={onClick}>
            <Image 
                src={url} 
                alt={previewMetadata?.title || 'Image'} 
                className="w-full h-full object-cover transition-transform duration-500 hover:scale-105 cursor-pointer"
            />
        </div>
      );
  }

  // 2. Detect Provider dynamically for robust handling
  const detectedType = detectProviderFromUrl(url);

  switch (detectedType) {
      case 'youtube':
          return (
            <div className={containerClass}>
                <YouTubeEmbed 
                    url={url} 
                    title={previewMetadata?.title} 
                    thumbnailUrl={previewMetadata?.imageUrl || media.thumbnail_url} 
                />
            </div>
          );
      
      case 'twitter':
          return (
             <GenericLinkPreview url={url} metadata={previewMetadata} type="twitter" />
          );

      case 'linkedin':
          return (
             <GenericLinkPreview url={url} metadata={previewMetadata} type="linkedin" />
          );

      default:
          return (
            <div className={containerClass}>
                <GenericLinkPreview url={url} metadata={previewMetadata} type={type} />
            </div>
          );
  }
};
