
import { Request, Response } from 'express';

let CATEGORIES_DB = [
  'Finance', 'Tech', 'Design', 'Politics', 'Environment', 
  'Health', 'Culture', 'Science', 'Lifestyle', 'Business', 'Growth'
];

export const getTags = async (req: Request, res: Response) => {
  res.json(CATEGORIES_DB);
};

export const createTag = async (req: Request, res: Response) => {
  const { name } = req.body;
  if (name && !CATEGORIES_DB.includes(name)) {
    CATEGORIES_DB.push(name);
    CATEGORIES_DB.sort();
  }
  res.status(201).json(CATEGORIES_DB);
};

export const deleteTag = async (req: Request, res: Response) => {
  const name = decodeURIComponent(req.params.name);
  CATEGORIES_DB = CATEGORIES_DB.filter(c => c !== name);
  res.status(204).send();
};
