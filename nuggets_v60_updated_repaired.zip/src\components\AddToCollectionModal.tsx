import React, { useState, useEffect } from 'react';
import { createPortal } from 'react-dom';
import { X, Plus, Check, Folder, Search, Lock, Globe, Loader2 } from 'lucide-react';
import { storageService } from '@/services/storageService';
import { Collection } from '@/types';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/useToast';

interface AddToCollectionModalProps {
  isOpen: boolean;
  onClose: () => void;
  articleIds: string[]; // Changed to array for bulk support
  mode?: 'public' | 'private';
}

export const AddToCollectionModal: React.FC<AddToCollectionModalProps> = ({ 
  isOpen, 
  onClose, 
  articleIds,
  mode = 'public' 
}) => {
  const [collections, setCollections] = useState<Collection[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [newCollectionName, setNewCollectionName] = useState('');
  const [isCreating, setIsCreating] = useState(false);
  const [processingId, setProcessingId] = useState<string | null>(null);
  
  const { currentUserId } = useAuth();
  const toast = useToast();

  useEffect(() => {
    if (isOpen) {
      loadCollections();
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    return () => { document.body.style.overflow = 'unset'; };
  }, [isOpen]);

  const loadCollections = async () => {
    const cols = await storageService.getCollections();
    // Filter to show only collections created by the user matching the mode
    setCollections(cols.filter(c => c.creatorId === currentUserId && c.type === mode));
  };

  const toggleCollection = async (collectionId: string, isFullySelected: boolean) => {
    setProcessingId(collectionId);
    try {
        if (isFullySelected) {
            // Remove all selected articles from this collection
            for (const id of articleIds) {
                await storageService.removeArticleFromCollection(collectionId, id, currentUserId);
            }
            toast.success(`Removed ${articleIds.length} nuggets from ${mode === 'private' ? 'folder' : 'collection'}`);
        } else {
            // Add all selected articles to this collection
            for (const id of articleIds) {
                await storageService.addArticleToCollection(collectionId, id, currentUserId);
            }
            toast.success(`Added ${articleIds.length} nuggets to ${mode === 'private' ? 'folder' : 'collection'}`);
        }
        await loadCollections();
    } catch (e) {
        toast.error("Failed to update");
    } finally {
        setProcessingId(null);
    }
  };

  const createCollection = async () => {
    if (!newCollectionName.trim()) return;
    setIsCreating(true);
    try {
        const newCol = await storageService.createCollection(newCollectionName, '', currentUserId, mode as 'public' | 'private');
        // Add all articles to new collection immediately
        for (const id of articleIds) {
            await storageService.addArticleToCollection(newCol.id, id, currentUserId);
        }
        setNewCollectionName('');
        setIsCreating(false);
        await loadCollections();
        toast.success(`Created ${mode === 'private' ? 'folder' : 'collection'} and added nuggets`);
    } catch (e) {
        toast.error("Failed to create");
    } finally {
        setIsCreating(false);
    }
  };

  if (!isOpen) return null;

  const filteredCollections = collections.filter(c => c.name.toLowerCase().includes(searchQuery.toLowerCase()));
  
  // Dynamic labels based on mode
  const title = mode === 'private' ? 'Save to Folder' : 'Add to Collection';
  const entityName = mode === 'private' ? 'folder' : 'collection';

  return createPortal(
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 sm:p-6" onClick={(e) => e.stopPropagation()}>
      <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm animate-in fade-in" onClick={onClose} />
      
      <div className="relative w-full max-w-sm bg-white dark:bg-slate-900 rounded-2xl shadow-xl flex flex-col overflow-hidden animate-in zoom-in-95 border border-slate-200 dark:border-slate-800">
        
        {/* Header */}
        <div className="px-4 py-3 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <h3 className="font-bold text-slate-900 dark:text-white">
                {title}
            </h3>
            {mode === 'private' ? <Lock size={14} className="text-slate-400" /> : <Globe size={14} className="text-slate-400" />}
          </div>
          <button onClick={onClose} className="p-1 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors">
            <X size={18} className="text-slate-500" />
          </button>
        </div>

        {/* Subheader for Bulk Context */}
        {articleIds.length > 1 && (
            <div className="px-4 py-2 bg-primary-50 dark:bg-primary-900/10 text-xs font-medium text-primary-700 dark:text-primary-400 border-b border-primary-100 dark:border-primary-900/20">
                Adding {articleIds.length} nuggets...
            </div>
        )}

        {/* Search / List */}
        <div className="p-4 flex flex-col gap-3 max-h-[60vh] overflow-y-auto custom-scrollbar">
          
          {/* Search Bar */}
          <div className="relative">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input 
              autoFocus
              className="w-full bg-slate-100 dark:bg-slate-800 rounded-lg pl-9 pr-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary-500/50 dark:text-white placeholder-slate-400 border-none"
              placeholder={`Find ${entityName}...`}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>

          {/* List */}
          <div className="flex flex-col gap-1">
            {filteredCollections.length > 0 ? filteredCollections.map(col => {
              // Check if ALL selected articles are in this collection
              const isFullySelected = articleIds.every(id => col.entries.some(e => e.articleId === id));
              // Check if SOME are in
              const isPartiallySelected = !isFullySelected && articleIds.some(id => col.entries.some(e => e.articleId === id));
              
              const isProcessing = processingId === col.id;

              return (
                <button
                  key={col.id}
                  onClick={() => toggleCollection(col.id, isFullySelected)}
                  disabled={isProcessing}
                  className="flex items-center justify-between p-2 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors group text-left"
                >
                  <div className="flex items-center gap-3 overflow-hidden">
                    <div className={`w-8 h-8 rounded-lg shrink-0 flex items-center justify-center ${isFullySelected ? 'bg-primary-100 text-primary-600 dark:bg-primary-900/20 dark:text-primary-400' : isPartiallySelected ? 'bg-slate-200 text-slate-600' : 'bg-slate-100 text-slate-500 dark:bg-slate-800 dark:text-slate-400'}`}>
                      {isProcessing ? <Loader2 size={16} className="animate-spin" /> : <Folder size={16} fill={isFullySelected ? "currentColor" : "none"} />}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className={`text-sm font-bold truncate ${isFullySelected ? 'text-primary-700 dark:text-primary-400' : 'text-slate-700 dark:text-slate-300'}`}>{col.name}</div>
                      <div className="text-[10px] text-slate-400">{col.entries.length} items</div>
                    </div>
                  </div>
                  {isFullySelected && <Check size={16} className="text-primary-500 shrink-0" />}
                  {isPartiallySelected && <div className="w-2 h-2 rounded-full bg-slate-300 dark:bg-slate-600 mr-1" />}
                </button>
              );
            }) : (
                <div className="text-center py-4 text-xs text-slate-400">
                    {searchQuery ? `No matching ${entityName}s found.` : `No ${entityName}s yet.`}
                </div>
            )}
          </div>

          {/* Create New */}
          {isCreating ? (
            <div className="flex items-center gap-2 animate-in fade-in slide-in-from-top-1">
              <input 
                autoFocus
                className="flex-1 bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-primary-500 dark:text-white"
                placeholder={`${mode === 'private' ? 'Folder' : 'Collection'} name...`}
                value={newCollectionName}
                onChange={(e) => setNewCollectionName(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && createCollection()}
              />
              <button onClick={createCollection} className="p-2 bg-primary-500 text-white rounded-lg hover:bg-primary-600"><Check size={16} /></button>
              <button onClick={() => setIsCreating(false)} className="p-2 bg-slate-100 dark:bg-slate-800 text-slate-500 rounded-lg"><X size={16} /></button>
            </div>
          ) : (
            <button 
              onClick={() => setIsCreating(true)}
              className="flex items-center gap-2 p-2 text-sm font-bold text-primary-600 dark:text-primary-400 hover:bg-primary-50 dark:hover:bg-primary-900/20 rounded-lg transition-colors justify-center mt-2 border border-dashed border-primary-200 dark:border-primary-800"
            >
              <Plus size={16} />
              <span>Create new {entityName}</span>
            </button>
          )}

        </div>
      </div>
    </div>,
    document.body
  );
};




