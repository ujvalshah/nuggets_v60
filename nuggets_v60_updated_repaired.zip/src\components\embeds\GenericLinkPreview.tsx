/* FORCE_REFRESH_V5_GENERIC_PREVIEW */
import React from 'react';
import { PreviewMetadata } from '@/types';
import { ExternalLink, Globe, Twitter, Linkedin, Youtube, Play } from 'lucide-react';
import { Image } from '../Image';

// --- Configuration ---

type LayoutStyle = 'vertical' | 'horizontal';

interface ProviderConfig {
  label: string;
  icon: React.ReactNode;
  brandColor: string; // Text color
  bgColor?: string; // Optional background accent
  layout: LayoutStyle;
}

const getProviderConfig = (providerName: string = '', type: string = ''): ProviderConfig => {
  const key = (providerName || type || '').toLowerCase();

  if (key.includes('twitter') || key.includes('x.com')) {
    return {
      label: 'View on X',
      icon: <Twitter size={12} fill="currentColor" />,
      brandColor: 'text-slate-900 dark:text-white',
      layout: 'vertical'
    };
  }
  if (key.includes('linkedin')) {
    return {
      label: 'View on LinkedIn',
      icon: <Linkedin size={12} fill="currentColor" />,
      brandColor: 'text-[#0077b5]',
      layout: 'vertical'
    };
  }
  if (key.includes('youtube')) {
    return {
      label: 'Watch on YouTube',
      icon: <Youtube size={12} fill="currentColor" />,
      brandColor: 'text-[#FF0000]',
      layout: 'vertical'
    };
  }
  
  // Default Generic / Article
  return {
    label: 'Open Link',
    icon: <Globe size={12} />,
    brandColor: 'text-slate-500',
    layout: 'horizontal'
  };
};

// --- Helper Functions ---

function extractHostname(url: string): string {
  try {
    const u = new URL(url);
    return u.hostname.replace(/^www\./, "");
  } catch {
    return url;
  }
}

function formatDate(dateString?: string): string {
  if (!dateString) return "";
  try {
    const d = new Date(dateString);
    if (Number.isNaN(d.getTime())) return "";
    return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
  } catch {
    return "";
  }
}

// --- Component ---

interface GenericLinkPreviewProps {
  url: string;
  metadata?: PreviewMetadata;
  type?: string;
}

export const GenericLinkPreview: React.FC<GenericLinkPreviewProps> = ({ 
  url, 
  metadata, 
  type 
}) => {
  // 1. Prepare Data
  const href = metadata?.finalUrl || metadata?.url || url;
  const hostname = extractHostname(href);
  const siteLabel = metadata?.siteName || metadata?.providerName || hostname;
  
  // Title Fallback logic
  let title = (metadata?.title || "").trim();
  if (!title) title = hostname;

  const description = metadata?.description?.trim();
  const imageUrl = metadata?.imageUrl;
  const faviconUrl = metadata?.faviconUrl;
  const author = metadata?.authorName;
  const date = formatDate(metadata?.publishDate);

  // 2. Determine Configuration
  const config = getProviderConfig(metadata?.providerName, type);
  
  // Force horizontal if no image (text only card), unless it's social (social text is main content)
  let layout = config.layout;
  if (!imageUrl && layout === 'vertical' && !config.label.includes('View on X')) {
      layout = 'horizontal';
  }

  const handleClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    window.open(href, '_blank', 'noopener,noreferrer');
  };

  // --- Render: Vertical Layout (Rich Card) ---
  // Large visual impact. Best for Social & Video.
  if (layout === 'vertical') {
    return (
      <div 
        onClick={handleClick}
        className="group relative w-full flex flex-col bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700/60 rounded-xl overflow-hidden cursor-pointer hover:border-slate-300 dark:hover:border-slate-600 transition-all shadow-sm hover:shadow-md mt-2"
      >
        {/* Hero Image */}
        {imageUrl && (
          <div className="relative w-full aspect-[1.91/1] bg-slate-100 dark:bg-slate-950 border-b border-slate-100 dark:border-slate-800 overflow-hidden">
             <Image 
                src={imageUrl} 
                alt={title} 
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
             />
             {config.label.includes('YouTube') && (
               <div className="absolute inset-0 flex items-center justify-center bg-black/10 group-hover:bg-black/20 transition-colors">
                  <div className="w-12 h-12 bg-white/90 rounded-full flex items-center justify-center shadow-lg text-red-600">
                    <Play size={20} fill="currentColor" className="ml-1" />
                  </div>
               </div>
             )}
          </div>
        )}

        {/* Content Box */}
        <div className="p-3.5 flex flex-col gap-2">
           {/* Header: Icon + Site */}
           <div className="flex items-center justify-between text-[11px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
              <div className="flex items-center gap-1.5">
                 {faviconUrl ? (
                   <img src={faviconUrl} className="w-4 h-4 rounded-sm" alt="" onError={(e) => e.currentTarget.style.display='none'} />
                 ) : (
                   <span className={config.brandColor}>{config.icon}</span>
                 )}
                 <span className="truncate max-w-[200px]">{siteLabel}</span>
              </div>
              <ExternalLink size={12} className="opacity-0 group-hover:opacity-100 transition-opacity text-slate-400" />
           </div>

           {/* Title */}
           <h3 className="text-[15px] font-bold text-slate-900 dark:text-slate-100 leading-snug line-clamp-2">
             {title}
           </h3>

           {/* Description (Optional) */}
           {description && (
             <p className="text-xs text-slate-600 dark:text-slate-400 line-clamp-2 leading-relaxed">
               {description}
             </p>
           )}
           
           {/* Author/Date Footer (Optional) */}
           {(author || date) && (
             <div className="pt-1 flex items-center gap-2 text-[10px] font-medium text-slate-400">
                {author && <span>{author}</span>}
                {author && date && <span>•</span>}
                {date && <span>{date}</span>}
             </div>
           )}
        </div>
      </div>
    );
  }

  // --- Render: Horizontal Layout (Article/News) ---
  // Dense information. Best for articles/blogs.
  return (
    <div
      onClick={handleClick}
      className="group w-full flex flex-col sm:flex-row bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700/60 rounded-xl overflow-hidden cursor-pointer hover:border-slate-300 dark:hover:border-slate-600 transition-all shadow-sm hover:shadow-md h-full mt-2"
    >
      {/* Text Side */}
      <div className="flex-1 p-3.5 flex flex-col justify-between min-w-0">
         <div>
            {/* Header */}
            <div className="flex items-center gap-2 mb-1.5 text-[10px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                {faviconUrl ? (
                   <img src={faviconUrl} className="w-3.5 h-3.5 rounded-sm" alt="" onError={(e) => e.currentTarget.style.display='none'} />
                 ) : (
                   <span className={config.brandColor}>{config.icon}</span>
                 )}
                <span className="truncate">{siteLabel}</span>
            </div>

            {/* Title */}
            <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 leading-snug line-clamp-2 mb-1.5 group-hover:text-primary-600 dark:group-hover:text-primary-400 transition-colors">
              {title}
            </h3>

            {/* Description */}
            {description && (
              <p className="text-xs text-slate-600 dark:text-slate-400 line-clamp-2 leading-relaxed">
                {description}
              </p>
            )}
         </div>

         {/* Footer */}
         {(author || date) && (
           <div className="mt-2 pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center gap-2 text-[10px] font-medium text-slate-400">
              {author && <span className="truncate max-w-[100px]">{author}</span>}
              {author && date && <span>•</span>}
              {date && <span>{date}</span>}
           </div>
         )}
      </div>

      {/* Image Side (Desktop: Right, Mobile: Bottom/Hidden depending on pref, here we stack or show side) */}
      {imageUrl && (
        <div className="relative sm:w-32 md:w-36 h-36 sm:h-auto shrink-0 bg-slate-100 dark:bg-slate-800 border-t sm:border-t-0 sm:border-l border-slate-100 dark:border-slate-800">
           <Image 
              src={imageUrl} 
              alt={title} 
              className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
           />
        </div>
      )}
    </div>
  );
};



